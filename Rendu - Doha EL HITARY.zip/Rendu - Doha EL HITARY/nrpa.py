import numpy as np
import logging
import time
from basefunctions import *
import colorlog

MAX_GRID_SIZE = 64

class Policy:
    def __init__(self):
        self.policy = np.zeros(MAX_GRID_SIZE * MAX_GRID_SIZE * 4)

class NRPA:
    def __init__(self, level, iterations,version, alpha=1.0):
        self.level = level
        self.iterations = iterations
        self.alpha = alpha
        self.logger = colorlog.getLogger()
        self.version = version

    def run(self, grid, log_file):
        strategy = Policy()
        best_grid = self.nrpa(self.level, grid, strategy, log_file)
        return best_grid.move_history_count, {"signature": sign_grid(best_grid), "moves": best_grid.move_history_count}

    def nrpa(self, level, node, strategy, log_file):
        if level == 0:
            return self.nrpa_playout(node, strategy, log_file)
        else:
            best_grid = Grid()
            best_grid.move_history_count = 0
            start_time = time.time()

            for i in range(self.iterations):
                iter_start_time = time.time()
                result = self.nrpa(level - 1, node, strategy, log_file)
                iter_time_elapsed = time.time() - iter_start_time

                if result.move_history_count >= best_grid.move_history_count:
                    best_grid = result.copy()
                    strategy = self.nrpa_adapt(strategy, node, best_grid, log_file)

                self.logger.info(
                    f"Iteration {i + 1}/{self.iterations} | Level: {level} | Moves: {best_grid.move_history_count} | "
                    f"Iteration Time: {iter_time_elapsed:.2f}s | Total Time: {time.time() - start_time:.2f}s | "
                    f"% Complete: {(i + 1) / self.iterations * 100:.2f}%",
                    extra={'color': 'cyan'})

            total_time_elapsed = time.time() - start_time
            self.logger.info(
                f"COMPLETED LEVEL {level} # TOTAL MOVES: {best_grid.move_history_count} # SIGNATURE: {sign_grid(best_grid):010d} | "
                f"Total Time: {total_time_elapsed:.2f}s",
                extra={'color': 'cyan'})
            return best_grid

    def nrpa_playout(self, grid, policy, log_file):
        current_grid = grid.copy()
        temp_grid = Grid()
        search_moves(current_grid,self.version)
        move_counter = 0

        while current_grid.move_count > 0:
            move = self.nrpa_select_move(current_grid, policy, log_file)
            move_counter += 1
            play_move(current_grid, temp_grid, move,self.version)
            search_moves_optimized(current_grid, temp_grid, move,self.version)

            if temp_grid.move_count > 0:
                move = self.nrpa_select_move(temp_grid, policy, log_file)
                move_counter += 1
                play_move(temp_grid, current_grid, move,self.version)
                search_moves_optimized(temp_grid, current_grid, move,self.version)
            else:
                current_grid, temp_grid = temp_grid, current_grid

        return current_grid

    def nrpa_select_move(self, grid, strategy, log_file):
        total_weight = 0.0
        self.nrpa_generate_code(grid, log_file,version=self.version)

        for i in range(grid.move_count):
            weight = np.exp(strategy.policy[grid.code[i]])
            if grid.priority[i] == 1000:
                total_weight += weight / 1000
            elif grid.priority[i] == 1005:
                total_weight += weight / 34
            else:
                total_weight += weight

        rand_num = np.random.rand()
        cumulative_prob = 0.0

        for i in range(grid.move_count):
            weight = np.exp(strategy.policy[grid.code[i]])
            if grid.priority[i] == 1000:
                cumulative_prob += weight / 1000 / total_weight
            elif grid.priority[i] == 1005:
                cumulative_prob += weight / 34 / total_weight
            else:
                cumulative_prob += weight / total_weight

            if cumulative_prob >= rand_num:
                return i

        logging.error(f"Problem in move selection. Random number: {rand_num:.6f}")
        for i in range(grid.move_count):
            logging.error(
                f"Move {i:02d} Priority: {grid.priority[i]} Code: {grid.code[i]} Weight: {np.exp(strategy.policy[grid.code[i]]) / total_weight:.6f}")
        exit(1)

    def nrpa_adapt(self, strategy, root, best_grid, log_file):
        start_time = time.time()
        new_strategy = Policy()
        new_strategy.policy = strategy.policy.copy()
        node = root.copy()
        search_moves(node,self.version)

        for i in range(node.move_history_count, best_grid.move_history_count):
            self.nrpa_generate_code(node, log_file,version=self.version)
            total_weight = 0.0
            target_move_index = -1

            for j in range(node.move_count):
                total_weight += np.exp(strategy.policy[node.code[j]])
                if node.moves[j] == best_grid.history[i]:
                    target_move_index = j
                    new_strategy.policy[node.code[j]] += self.alpha

            if target_move_index == -1:
                logging.error(f"Move from best grid {i} not found. Something is wrong")
                log_file.write(f"Move from best grid {i} not found. Something is wrong\n")
                log_file.write("BEST\n")
                display_game(best_grid, log_file)
                log_file.write("NODE\n")
                display_game(node, log_file)
                log_file.close()
                exit(1)

            for j in range(node.move_count):
                new_strategy.policy[node.code[j]] -= self.alpha * np.exp(strategy.policy[node.code[j]]) / total_weight
            play_move(node, node, target_move_index,self.version)
            search_moves(node,self.version)

        self.logger.info(
            f"ADAPTED STRATEGY # ALPHA: {self.alpha} # ADAPTED MOVES: {node.move_history_count - root.move_history_count} "
            f"# PREV.SIG: {sign_grid(root):010d} # NEW.SIG: {sign_grid(node):010d} # TIME: {time.time() - start_time:.2f}s",
            extra={'color': 'green'})
        return new_strategy

    def nrpa_generate_code(self, grid, log_file,version):
        dirX, dirY, dirD, dirO, dirDO = get_directions(version)
        directions_x, directions_y ,directions_D,directions_O,directions_DO = dirX, dirY, dirD, dirO, dirDO

        for i in range(grid.move_count):
            move_x = unpack_x(grid.moves[i])
            move_y = unpack_y(grid.moves[i])
            move_d = unpack_direction(grid.moves[i])
            move_k = unpack_k(grid.moves[i])

            end_x1 = move_x + move_k * directions_x[move_d]
            end_y1 = move_y + move_k * directions_y[move_d]
            start_x2 = move_x + (move_k - 4) * directions_x[move_d]
            start_y2 = move_y + (move_k - 4) * directions_y[move_d]

            n1 = (MAX_GRID_SIZE - 1) * end_y1 + end_x1
            n2 = (MAX_GRID_SIZE - 1) * start_y2 + start_x2

            if n1 < n2:
                grid_code = 4 * n1 + 0 if end_x1 < start_x2 else 1 if end_x1 == start_x2 else 2 if end_y1 > start_y2 else 3
            else:
                grid_code = 4 * n2 + 0 if start_x2 < end_x1 else 1 if start_x2 == end_x1 else 2 if start_y2 > end_y1 else 3

            grid.code[i] = grid_code

    def display_policy(self, strategy, log_file):
        log_file.write("STRATEGY\n")
        for index in range(MAX_GRID_SIZE * MAX_GRID_SIZE * 4):
            if strategy.policy[index] != 0:
                log_file.write(
                    f"exp(policy)={np.exp(strategy.policy[index])} policy={strategy.policy[index]} code={index:05d}\n")
