import logging
import random
import time
from basefunctions import *

class NMCS:
    def __init__(self, level, iterations, version, alpha=1.0):
        self.level = level
        self.iterations = iterations
        self.alpha = alpha
        self.version = version

    def run(self, game, log_file):
        best_score, best_strategy = self.search(game, self.level)
        return best_score, best_strategy

    def search(self, game, level):
        if level == 0:
            return self.playout(game)
        
        best_score = -float('inf')
        best_strategy = None

        for _ in range(self.iterations):
            new_game = game.copy()
            score, strategy = self.search(new_game, level - 1)
            if score > best_score:
                best_score = score
                best_strategy = strategy
        
        return best_score, best_strategy

    def playout(self, game):
        moves = []
        start_time = time.time()
        with open("grid_moves.txt", "w") as file:
            while not is_terminal(game, version=self.version):
                search_moves(game, self.version)
                if game.move_count == 0:
                    logging.warning("No moves found for the current grid")
                    break
                move = random.randint(0, game.move_count - 1)
                play_move(game, game, move, self.version)
                moves.append(move)
                file.write(f"Move applied: {move}\n")
                self.display_game(game, file)

                
        signature = sign_grid(game)
        time_taken = time.time() - start_time
        logging.info(f"ADAPTED STRATEGY # ALPHA: {self.alpha} # ADAPTED MOVES: {len(moves)} # SIGNATURE: {signature} # TIME: {time_taken:.2f}s")
        return get_reward(game), {"moves": moves, "signature": signature, "time": time_taken}

    def display_game(self, game, file):
        for row in game.grid:
            file.write(' '.join(str(cell) for cell in row) + '\n')
        file.write('\n')

