import logging
import argparse
import time
import pandas as pd
from basefunctions import *
from nrpa import NRPA
from nmcs import NMCS
from EnhancedNRPA import EnhancedNRPA

def setup_logging():
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
    )

def parse_arguments():
    parser = argparse.ArgumentParser()
    parser.add_argument('--algorithm', type=str, choices=['nrpa', 'nmcs','enhanced_nrpa'], required=True, help='Algorithm to use (nmcs, nrpa or enhanced_nrpa)')
    parser.add_argument('--level', type=int, required=True, help='Level of the algorithm')
    parser.add_argument('--iterations', type=int, required=True, help='Number of iterations for the algorithm')
    parser.add_argument('--alpha', type=float, default=1.0, help='Alpha value for strategy adaptation (only for NRPA)')
    parser.add_argument('--version', type=str, choices=['5T'], required=False, help='Version of the game to use (5T)')
    return parser.parse_args()


def main():
    args = parse_arguments()
    setup_logging()
    
    logging.info("Initializing game")
    game = Grid()
    initialize_game(game)
    logging.info("Game initialized")

    if args.algorithm == 'nrpa':
        logging.info(f"Starting NRPA with level={args.level}, iterations={args.iterations}, alpha={args.alpha}, version={args.version}")
        algorithm = NRPA(level=args.level, iterations=args.iterations, alpha=args.alpha,version=args.version)
    elif args.algorithm == 'nmcs':
        logging.info(f"Starting NMCS with level={args.level}, iterations={args.iterations}, version={args.version}")
        algorithm = NMCS(level=args.level, iterations=args.iterations,version=args.version)
    elif args.algorithm == 'enhanced_nrpa':
        logging.info(f"Starting Enhanced NRPA with level={args.level}, iterations={args.iterations}, alpha={args.alpha}, version={args.version}")
        algorithm = EnhancedNRPA(level=args.level, iterations=args.iterations, alpha=args.alpha, version=args.version)
    


    start_time = time.time()
    best_score, best_strategy = algorithm.run(game, open("game_output.txt", "w"))
    total_time = time.time() - start_time

    logging.info(f"Move 1 completed ## Total moves: {best_score} ## Time elapsed: {total_time:.2f}s")
    
    # with open("game_output.txt", "w") as file:
    #     logging.info("Displaying game")
    #     display_game(game, file)
    #     logging.info("Game displayed")
    
    results = {
        "Algorithm": [args.algorithm],
        "Level": [args.level],
        "Moves": [best_score],
        "Signature": [best_strategy['signature']],
        "Time (s)": [total_time],
        "Version": [args.version]
    }
    df = pd.DataFrame(results)
    df.to_csv("data.csv", index=False)
    # logging.info("Results saved to data.csv")

    logging.info("+---------------------------------------------------+")
    logging.info(f"    Algorithm : {args.algorithm}   & Version : {args.version} ")
    logging.info(f"    Level : {args.level}          & Iterations : {args.iterations} ")
    logging.info(f"    Best score : {best_score} ")
    logging.info(f"    Time  : {total_time:.2f}(s)    & Signature : {best_strategy['signature']}")
    logging.info("+----------------------------------------------------+")

if __name__ == '__main__':
    main()
