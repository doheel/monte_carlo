import numpy as np
import time
from basefunctions import *
from nrpa import *

class EnhancedNRPA(NRPA):
    def __init__(self, level, iterations, version, alpha=1.0, exploration_constant=1.414):
        super().__init__(level, iterations, version, alpha)
        self.exploration_constant = exploration_constant

    def run(self, grid, log_file):
        strategy = Policy()
        best_grid = self.enhanced_nrpa(self.level, grid, strategy, log_file)
        return best_grid.move_history_count, {"signature": sign_grid(best_grid), "moves": best_grid.move_history_count}

    def enhanced_nrpa(self, level, node, strategy, log_file):
        if level == 0:
            return self.nrpa_playout(node, strategy, log_file)
        else:
            best_grid = Grid()
            best_grid.move_history_count = 0
            start_time = time.time()

            for i in range(self.iterations):
                iter_start_time = time.time()
                result = self.enhanced_nrpa(level - 1, node, strategy, log_file)
                iter_time_elapsed = time.time() - iter_start_time

                if result.move_history_count >= best_grid.move_history_count:
                    best_grid = result.copy()
                    strategy = self.nrpa_adapt(strategy, node, best_grid, log_file)

                self.logger.info(
                    f"Iteration {i + 1}/{self.iterations} | Level: {level} | Moves: {best_grid.move_history_count} | "
                    f"Iteration Time: {iter_time_elapsed:.2f}s | Total Time: {time.time() - start_time:.2f}s | "
                    f"% Complete: {(i + 1) / self.iterations * 100:.2f}%",
                    extra={'color': 'cyan'})

            total_time_elapsed = time.time() - start_time
            self.logger.info(
                f"COMPLETED LEVEL {level} # TOTAL MOVES: {best_grid.move_history_count} # SIGNATURE: {sign_grid(best_grid):010d} | "
                f"Total Time: {total_time_elapsed:.2f}s",
                extra={'color': 'cyan'})
            return best_grid

    def enhanced_nrpa_playout(self, grid, policy, log_file):
        current_grid = grid.copy()
        temp_grid = Grid()
        search_moves(current_grid, self.version)
        move_counter = 0

        while current_grid.move_count > 0:
            move = self.nrpa_select_move(current_grid, policy, log_file)
            move_counter += 1
            play_move(current_grid, temp_grid, move, self.version)
            search_moves_optimized(current_grid, temp_grid, move, self.version)

            if temp_grid.move_count > 0:
                move = self.nrpa_select_move(temp_grid, policy, log_file)
                move_counter += 1
                play_move(temp_grid, current_grid, move, self.version)
                search_moves_optimized(temp_grid, current_grid, move, self.version)
            else:
                current_grid, temp_grid = temp_grid, current_grid

        return current_grid
